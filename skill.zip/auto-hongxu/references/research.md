# 动态车型研究与 Fact Pack

## 研究目标

Research the actual model line, model year, market, sale status and variant matrix. Do not invent a trim from incompatible parts. Model-line advertising may combine independently verified entry prices and flagship selling points in one script while keeping their scopes clear. For trim-specific copy, constrain the facts to the requested trim.

### A. Initial Discovery

1. 用品牌、车型、别名和市场查找官方信息；用户使用拼写错误或简称时验证真实名称，不自行补造车型。
2. Identify the latest on-sale model line, its entry trim and price, its highest on-sale trim and core configurations, and relevant model-line maxima with exact source variant and test cycle. Research both tracks independently. Do not infer that every variant has flagship-only features. When a particular trim is requested, research that trim instead.
3. 若新年款尚未上市，不以预售或传闻当作正式在售车型；若找不到有效官方信息，标明限制。

### B. Dynamic Research Plan

从车型定位、受众、主题和可拍素材决定研究的优先级（HIGH/MEDIUM/LOW）。例：

- 家庭 SUV/MPV：乘员和行李、二三排、儿童场景、舒适性、长途补能、真实的辅助驾驶与安全配置。
- 性能车型：动力/电驱、制动、底盘、操控和真实的性能指标；不编造赛道或加速实测。
- 越野车：驱动系统、差速锁、悬架、通过性、涉水与使用限制；不保证极端路况安全。
- 商用车：货厢、载货/载重、补能、营运成本、售后；成本必须有计算依据与前提。
- 新能源车型：CLTC/WLTC 等工况、驱动/电池版本、补能时间区间、充电条件。只在来源支持时写实际续航或费用。

以上为示例，不硬编码研究目录。默认综合营销应优先查能支撑多个不同购买维度的事实，并独立核查适用价格、优惠政策；短口播无需完整评测级研究，但不得只查一个卖点就结束。用可用的检索工具执行，按复杂度扩展检索；完整研究最多约 25 个有效查询、最多 2 轮针对冲突或缺口追查，若已满足需求可提前结束。不可将查询次数当质量指标。

### C. 深度研究与来源

首选制造商官网/官方配置表/新闻稿、品牌官方活动公告、适用市场的经销商正式政策材料。其次可靠汽车媒体或公开测试，明确测试条件、出处和媒体属性。网页标题/搜索摘要不足以确认精确参数时打开实际页面。引用只用实际检索到、确实支持该事实的来源，不伪造链接、机构、日期、引用编号。

分别检查数字、单位、年款/版本、测量工况、测试环境、选装与标配。技术名称按实际名称写；对同一指标出现多个值时先检查版本与定义。官方材料相互冲突，或证据无法解决时标记 `CONFLICT` 并排除具体数字；不要挑营销上更好看的数字。

### D. Price & Policy 独立核查

价格按官方指导价、预售价、终端成交价、置换价、金融方案区分；优惠与权益不等于裸车减免。确认适用时间、地区、车型/配置、对象、前置条件、叠加限制、门店差异。不得将用户提供的门店政策写成全国统一政策，不得把库存、退网、清库、售完无补、限时等断言编造出来。用户提供政策可使用但记录 `USER_PROVIDED`，不声称已经第三方核实。将来源、适用范围与核验结果保留在事实包。台词避免“部分门店”“以门店为准”等泛化防御话术；能用准确直接的销售表述（如置换权益的真实适用对象）则使用，无法在短句中保持事实准确的局部优惠则省略，不擅自扩大范围。无可信当前政策：`NO_CONFIRMED_CURRENT_POLICY`，仅写已核实的卖点或请用户提供政策。 For model-line advertising, store the verified entry/starting price and the flagship configuration separately. State the price with its real category (official starting price, trade-in starting price, etc.) and a starting-price marker; never represent a conditional offer as an unconditional base price. Do not downgrade the flagship selling-point pool to the entry trim. If a maximum belongs to a different trim, identify its scope rather than representing a fictitious combined flagship.

### E. Fact Pack（内部结构，可按需展示）

```yaml
vehicleIdentity:
  brand: <品牌>
  model: <车型>
  market: <市场>
  modelYear: <年款或未知>
  trim: <配置或明确适用范围>
  saleStatus: <已核实状态或未知>
  assumptions: []
modelLineScope:
  mode: SERIES
  entryTrim: <verified entry trim>
  startingPriceFactRef: <price fact ID or unknown>
  flagshipTrim: <verified highest trim>
  flagshipFactRefs: []
  seriesMaximaFactRefs: []
  # In TRIM mode, use the requested variant only.
researchPlan:
  audience: <受众>
  topics: []
facts:
  - id: F01
    property: <参数或功能>
    value: <经来源支持的值>
    unit: <单位或无>
    scope: <版本、工况、条件>
    status: CONFIRMED
    sources:
      - title: <来源标题>
        url: <实际来源URL>
        date: <发布/更新时间或未知>
    evidenceNote: <简明依据，不大段复制>
conflicts: []
pricing: []
policy: []
sellingPoints:
  - theme: <购买理由>
    userProblem: <真实痛点>
    userBenefit: <收益>
    scenarios: []
    factRefs: [F01]
    strength: HIGH
    visualPotential: <能拍的动作或画面>
```

`CONFIRMED` = 来源支持且范围一致；`CONFLICT` = 可靠材料矛盾且未解决；`LOW_CONFIDENCE` = 来源薄弱或缺少范围；`USER_PROVIDED` = 用户直接提供但未独立核查。仅选 `CONFIRMED` 和可按提供口径使用的 `USER_PROVIDED` 进入营销正文，不把后一类标为官方确认。证据无法复查时降低置信或省略。按语义、技术名称、数值/单位、适用版本去重，保留主要来源和补充来源。

### F. Fact → Selling Point → Copy

例如（纯示意，不代表任何真实车型）：若已确认某大尺寸车具有后轮转向、且来源提供具体转弯半径，则事实可支撑“大车在窄路的灵活性”。卖点是更容易完成掉头和地库转向的实际价值，画面可在许可、安全的空间演示。不要将参数本身换个说法当卖点，不添加未验证的“全级别最小”或绝对保证。

同一批次共享 Fact Pack；局部改稿复用本对话仍有效的事实，新批次重新核实价格政策、最新年款等易变信息。没有运行时缓存时只依赖对话中的已有事实，不承诺原 Web 工具的 60 分钟内存缓存。

### G. 输出来源

默认仅交付可复制的台词块，内部保留事实与来源对应，不把事实包、核验过程或防御性备注混入台词。用户要求来源、平台要求引用或确有重要不确定性时，在复制块之外简短列明。若要求完整研究报告，按车型身份、事实表（版本、状态、来源）、冲突、卖点、政策顺序输出。
